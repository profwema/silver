A Pen created at CodePen.io. You can find this one at http://codepen.io/tutsplus/pen/ZKpNwm.

 Read full tutorial by George Martsoukos [on Envato Tuts+](https://webdesign.tutsplus.com/tutorials/building-a-horizontal-timeline-with-css-and-javascript--cms-28378)!